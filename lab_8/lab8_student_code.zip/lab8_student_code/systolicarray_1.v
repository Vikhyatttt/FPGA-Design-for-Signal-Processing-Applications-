`timescale 1ns / 1ps

module systolicarray_1(
clk,
rst,
mi0,
mi1,
mor
    );

parameter size=8;
parameter decimal=4;

input clk,rst;
input[4*size-1:0] mi0;
input[4*size-1:0] mi1;
output reg[4*size-1:0] mor;

wire[4*size-1:0] mo;

always@(posedge clk or negedge rst)begin
    if(~rst)begin
        mor<=0;
    end
    else begin
        mor<=mo;
    end
end

wire[size-1:0] umi1[7:0];
wire[size-1:0] umi2[7:0];
wire[size-1:0] uai[7:0];
wire[size-1:0] uoutmi1[7:0];
wire[size-1:0] uoutmi2[7:0];
wire[size-1:0] uout[7:0];

genvar gi;

generate
    for(gi=0;gi<8;gi=gi+1)begin : genu
        systolicarray_1_unit #(.size(size),.decimal(decimal)) ui(umi1[gi],umi2[gi],uai[gi],uoutmi1[gi],uoutmi2[gi],uout[gi]);
    end
endgenerate

// Start of your code.


// End of your code.

endmodule
