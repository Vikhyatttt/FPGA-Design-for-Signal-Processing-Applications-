`timescale 1ns / 1ps

module izigzag(
clk,
rst,
zigzag,
outdata,
finish
    );
    
input clk,rst;
input[32*64-1:0] zigzag;//[64th data (32bits)]..[2nd data][1st data]
output reg[32*64-1:0] outdata;
output reg finish;

always@(posedge clk or negedge rst)begin
    if(~rst)begin
        outdata<=0;
        finish<=0;
    end
    else begin
    // Example:
    // outdata[31:0]<=zigzag[31:0];
    // outdata[63:32]<=zigzag[63:32];
    // outdata[287:256]<=zigzag[95:64];
    // Start of your code ====================================
   












   
    // End of your code ======================================
    finish<=1;
    end
end

endmodule
