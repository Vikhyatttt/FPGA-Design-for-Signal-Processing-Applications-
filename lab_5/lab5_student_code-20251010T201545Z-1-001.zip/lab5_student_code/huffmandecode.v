`timescale 1ns / 1ps

module huffmandecode(
clk,
rst,
code,
hufftable,
huffsymbol,
data,
length,
finish
    );
input clk,rst;
input[15:0] code;
input[8*16-1:0] hufftable;
input[8*256-1:0] huffsymbol;
output reg[7:0] data;
output reg[7:0] length;
output reg finish;

reg[7:0] count;

reg[15:0] UB;
reg[15:0] SC;
reg[15:0] dis;
reg[15:0] index;
reg[15:0] code_tmp;


always@(posedge clk or negedge rst)begin
    if(~rst)begin
    // Start of your code ====================================





    // End of your code ======================================

    end
    else if(finish==0)begin
	if(count<=15)begin
    	// Start of your code ====================================
        







        
    	// End of your code ======================================    
	count = count + 1;
	end
        else begin
            length<=0;
            finish<=1;
            data<='hff;
        end   
    end
end

endmodule
