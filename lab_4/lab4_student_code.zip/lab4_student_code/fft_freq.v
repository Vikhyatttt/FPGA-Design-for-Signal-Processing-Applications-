`timescale 1ns / 1ps

module fft_freq(
clk,
rst,
fr,     // Real part of the 8 inputs.
fi,     // Imag part of the 8 inputs.
Fr,     // Real part of the 8 outputs.
Fi      // Imag part of the 8 outputs.
    );

parameter width=8;
parameter decimal=4;

input clk,rst;

// fr: the real part of input
// fi: the imag part of input
// inputReal[i]=fr[(i+1)*width-1:i*width]
// inputImag[i]=fi[(i+1)*width-1:i*width]
input [8*width-1:0] fr,fi; 

// Fr: the real part of output
// Fi: the imag part of output
// outputReal[i]=Fr[(i+1)*width-1:i*width]
// outputImag[i]=Fi[(i+1)*width-1:i*width]
output reg [8*width-1:0] Fr,Fi;

// Wires for the outputs.                          
wire[8*width-1:0] Fwr,Fwi;

// Outputs of level 1
wire[width-1:0] o0r[7:0];
wire[width-1:0] o0i[7:0];

// Outputs of level 2
wire[width-1:0] o1r[7:0];
wire[width-1:0] o1i[7:0];


// Start of your code
//-----------------------------level 1---------------------------//




//-----------------------------level 2---------------------------//





//-----------------------------level 3---------------------------//



// End of your code

endmodule