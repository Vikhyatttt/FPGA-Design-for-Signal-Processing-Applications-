`timescale 1ns / 1ps

module kalman(
clk,
rst,
n,      // Input: Index of the inputs.
u,      // Input: Scalar: Acceleration.
z,      // Input: 1x2 Z Vector; Measurement of x.
x0,     // Initial state of x.
P0,     // Initial state of P.
F,      // Input: 2x2 F Matrix.
B,      // Input: 2x1 B Vector.
Q,      // Input: 2x2 Q Matrix.
H,      // Input: 2x2 H Matrix.
R,      // Input: 2x2 R Matrix.
no,     // Output: n_out.
xo,     // Output: x_out.
outen   // Output: output enable: a flag signal. 
    );

parameter len=2;		// # of input size.
parameter dsize=16;		// Width of each data.
parameter decimal=10;	// Width of fraction.

input clk,rst;
input[dsize-1:0] n;
input[dsize-1:0] u;
input[dsize*len-1:0] z;
input[dsize*len-1:0] x0;
input[dsize*len*len-1:0] P0;
input[dsize*len*len-1:0] F,H,Q,R;
input[dsize*len-1:0] B;
output reg[dsize-1:0] no;
output reg[dsize*len-1:0] xo;
output reg outen;


reg[dsize-1:0] mi[1:0][3:0];  // intermediate input 2x4 matrix
wire[dsize-1:0] mo[3:0];      // intermediate output 1x4 vector

wire[dsize*2*2-1:0] mmin1;  //intermediate operands A in 2x2 matrix
wire[dsize*2*2-1:0] mmin2;  //intermediate operands B in 2x2 matrix
wire[dsize*2*2-1:0] mmout;  //intermediate results C in 2x2 matrix

assign mmin1[dsize-1:0]=mi[0][0];        // Fetch half of mi
assign mmin1[2*dsize-1:dsize]=mi[0][1];
assign mmin1[3*dsize-1:2*dsize]=mi[0][2];
assign mmin1[4*dsize-1:3*dsize]=mi[0][3];

assign mmin2[dsize-1:0]=mi[1][0];        // Fetch the oter half of mi
assign mmin2[2*dsize-1:dsize]=mi[1][1];
assign mmin2[3*dsize-1:2*dsize]=mi[1][2];
assign mmin2[4*dsize-1:3*dsize]=mi[1][3];

assign mo[0]=mmout[dsize-1:0];
assign mo[1]=mmout[2*dsize-1:dsize];
assign mo[2]=mmout[3*dsize-1:2*dsize];
assign mo[3]=mmout[4*dsize-1:3*dsize];


/////////////////////////////////////////////////////////////////////
//  | mo[0] mo[1] |     | mi[0][0] mi[0][1] |   | mi[1][0] mi[1][1] |
//  | mo[2] mo[3] | =   | mi[0][2] mi[0][3] | x | mi[1][2] mi[1][3] |
/////////////////////////////////////////////////////////////////////
matmul22 #(.size(dsize),.decimal(decimal)) mm0(mmin1,mmin2,mmout);

reg[dsize-1:0] divin;
wire[dsize-1:0] divout;

// divout = 1 / divin.
divider #(.size(dsize),.decimal(decimal)) d0(divin,divout);


reg[dsize-1:0] nk;
reg zenk;
reg[dsize*len-1:0] uk,zk,xkm,xkp,yk;    // Vector; Width = 16x2 = 32.
reg[dsize*len*len-1:0] Pkm,Kk,Pkp,temp;      // Matrix; Width = 16x2x2 = 64.

reg [4:0] state;
integer i,j;

always@(posedge clk or negedge rst)begin
    if(~rst)begin
        // start your code here







        //end your code here
    end
    else begin
        // start your code here
        // case ()






        // endcase
        //end your code here
    end
end

endmodule